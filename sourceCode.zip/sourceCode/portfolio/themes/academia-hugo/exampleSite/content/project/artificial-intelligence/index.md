---
title: Artificial Intelligence
summary: Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam, eius.
tags:
- Demo
- robotics
date: "2016-04-27T00:00:00Z"

# Optional external URL for project (replaces project detail page).
external_link: 

image:
  caption: Photo by Toa Heftiba on Unsplash
  focal_point: Smart
---
