---
# Display name
name: Shagun Agarwal
avatar_image: "rover_1.jpg"
# Username (this should match the folder name)
authors:
- admin
# resume download button
btn:
- url : "files/Academic_CV_3P.pdf"
  label : "Academic CV"

# Is this the primary user of the site?
superuser: true

# Role/position
role: Research Scholar

# Organizations/Affiliations
organizations:
- name: Department of Ocean Engineering
  url: "http://doe.iitm.ac.in/"
organizations2:
- name: IIT Madras
  url: "https://www.iitm.ac.in/"

# Short bio (displayed in user profile at end of posts)
bio: My research interests include computational methods, ocean engineering, fluid dynamics and robotics.

# Should the user's education and interests be displayed?
display_education: yes

interests:
- Finite Element Method
- Finite Difference Method
- Meshfree Methods
- Hybrid Modelling

interests2:
- Fluid-Structure Interaction
- Near-Shore Waves
- Ship-Generated Waves
- Turbulence Modelling
- Storm surge due to Cylones

# Social/academia Networking
# For available icons, see: https://sourcethemes.com/academic/docs/widgets/#icons
#   For an email link, use "fas" icon pack, "envelope" icon, and a link in the
#   form "mailto:your-email@example.com" or "#contact" for contact widget.
social:
- icon: envelope
  icon_pack: fas
  link: '#contact'  # For a direct email link, use "mailto:shagun.1994@gmail.com".
- icon: github
  icon_pack: fab
  link: https://github.com/shagun751
- icon: researchgate
  icon_pack: ai
  link: https://www.researchgate.net/profile/Shagun-Agarwal
- icon: orcid
  icon_pack: ai
  link: https://orcid.org/0000-0003-1922-4242
- icon: google-scholar
  icon_pack: ai
  link: https://scholar.google.com/citations?user=-KuJxKYAAAAJ&hl=en
- icon: publons
  icon_pack: ai
  link: https://www.webofscience.com/wos/author/record/328472
- icon: scopus
  icon_pack: ai
  link: https://www.scopus.com/authid/detail.uri?authorId=57205674472
- icon: linkedin
  icon_pack: fab
  link: https://www.linkedin.com/in/shagun-agarwal-62694757/


# Link to a PDF of your resume/CV from the About widget.
# To enable, copy your resume/CV to `static/files/cv.pdf` and uncomment the lines below.  
#- icon: cv
#  icon_pack: ai
#  link: files/Shagun_cv_3P_20210724.pdf

# Enter email to display Gravatar (if Gravatar enabled in Config)
email: ""
  
# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.  
user_groups:
- Researchers
- Visitors
---

Engineer, interested in solving realistic problems.

<!---![reviews](../../img/rect2_2_label.png)--->