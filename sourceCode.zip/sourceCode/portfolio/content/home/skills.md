+++
# A Skills section created with the Featurette widget.
widget = "featurette"  # See https://sourcethemes.com/academic/docs/page-builder/
headless = true  # This file represents a page section.
active = true  # Activate this widget? true/false
weight = 30  # Order that this section will appear.

title = "Skills"
subtitle = ""

# Showcase personal skills or business features.
# 
# Add/remove as many `[[feature]]` blocks below as you like.
# 
# For available icons, see: https://sourcethemes.com/academic/docs/widgets/#icons

[[feature]]
  icon = "code"
  icon_pack = "fas"
  name = "FORTRAN"

[[feature]]
  icon = "code"
  icon_pack = "fas"
  name = "C / C++"

[[feature]]
  icon = "code"
  icon_pack = "fas"
  name = "Python"

[[feature]]
  icon = "code"
  icon_pack = "fas"
  name = "OpenACC"

[[feature]]
  icon = "laptop-code"
  icon_pack = "fas"
  name = "Linux"

[[feature]]
  icon = "file-code"
  icon_pack = "fas"
  name = "LaTeX"

[[feature]]
  icon = "microchip"
  icon_pack = "fas"
  name = "Arduino"

[[feature]]
  icon = "microchip"
  icon_pack = "fas"
  name = "Raspberry Pi"

[[feature]]
  icon = "robot"
  icon_pack = "fas"
  name = "Robotics"

[[feature]]
  icon = "calculator"
  icon_pack = "fas"
  name = "MATLAB"

[[feature]]
  icon = "calculator"
  icon_pack = "fas"
  name = "Mathematica"

[[feature]]
  icon = "water"
  icon_pack = "fas"
  name = "ANSYS"

[[feature]]
  icon = "water"
  icon_pack = "fas"
  name = "StarCCM+"

[[feature]]
  icon = "water"
  icon_pack = "fas"
  name = "OpenFOAM"

[[feature]]
  icon = "pencil-ruler"
  icon_pack = "fas"
  name = "AutoCAD"

[[feature]]
  icon = "terminal"
  icon_pack = "fas"
  name = "Server Management"

#[[feature]]
#  icon = "searchengin"
#  icon_pack = "fab"
#  name = "Research"
#  parcent = "95%"

+++
