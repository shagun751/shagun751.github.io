+++
# Experience widget.
widget = "experience"  # See https://sourcethemes.com/academic/docs/page-builder/
headless = true  # This file represents a page section.
active = true  # Activate this widget? true/false
weight = 40  # Order that this section will appear.

title = "Education"
subtitle = ""

# Date format for experience
#   Refer to https://sourcethemes.com/academic/docs/customization/#date-format
date_format = "Jan 2006"

# Experiences.
#   Add/remove as many `[[experience]]` blocks below as you like.
#   Required fields are `title`, `company`, and `date_start`.
#   Leave `date_end` empty if it's your current employer.
#   Begin/end multi-line descriptions with 3 quotes `"""`.
[[experience]]
  title = "Bachelor of Technology in Naval Architecture and Ocean Engineering"
  company = "Dept. of Ocean Engineering, IIT Madras"
  company_url = "https://doe.iitm.ac.in/"
  location = "Chennai, India"
  date_start = "2012-07-01"
  date_end = "2016-07-01"
  description = """
  Minor in Systems Engineering.

  Worked on robotics projects under [Prof. Prabhu Rajagopal](https://sites.google.com/site/iitmprabhu/). 

  Worked on numerical coastal engineering project under [Dr. V. Sriram](https://home.iitm.ac.in/vsriram/)
  """

[[experience]]
  title = "Master of Technology in Applied Mechanics"
  company = "Dept. of Applied Mechanics IIT Madras Madras"
  company_url = "https://apm.iitm.ac.in/"
  location = "Chennai, India"
  date_start = "2015-07-01"
  date_end = "2017-07-01"
  description = """
  Guided by [Prof. Arul Prakash](https://home.iitm.ac.in/arulk/) and [Prof. K. Murali](https://doe.iitm.ac.in/murali/)

  [Thesis](https://www.researchgate.net/publication/331099728_Numerical_Investigation_of_Fluid-Structure_Interaction_Using_Immersed_Boundary_Method): Numerical Investigation of Fluid-Structure Interaction Using Immersed Boundary Method"""

[[experience]]
  title = "PhD in Ocean Engineering"
  company = "Dept. of Ocean Engineering, IIT Madras"
  company_url = "https://doe.iitm.ac.in/"
  location = "Chennai, India"
  date_start = "2017-07-01"
  date_end = "2022-07-01"
  description = """
  Guided by [Dr. V. Sriram](https://home.iitm.ac.in/vsriram/) and [Prof. K. Murali](https://doe.iitm.ac.in/murali/) with correspondence from [Prof. Shiqiang Yan](https://www.city.ac.uk/about/people/academics/shiqiang-yan) 
  
  Thesis: Wave-structure interaction by coupled Boussinesq (FEM) and Navier-Stokes (particlebased) models in 3D  """
+++
