---
title: Hybrid Boussinesq-MLPG model
summary: Coupling between mesh-based 2DH potential flow and particle-based 3D viscous flow free-surface models
tags:
- MLPG
- Numerical
- Meshless
- Boussinesq
- FEM
- Hybrid
date: "2021-03-04T00:00:00Z"

# Optional external URL for project (replaces project detail page).
external_link: 

image:
  caption: Simulation by Shagun Agarwal
  focal_point: Smart #Options: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight
  preview_only: true
  
authors:
- admin

---

{{< figure src="../../img/project_bqml_base_test.gif" title="**Figure:** Simulation of coupling for wave generation in 3D-particle based model using input from 2DH mesh-based model." >}}
