---
title: Storm-surge FEM model
summary: Efficient GPU parallel FEM model for predicting storm-surge due to cylone. 
tags:
- Numerical
- Boussinesq
- FEM
- Cyclone
- GPU
date: "2021-03-04T00:00:00Z"

# Optional external URL for project (replaces project detail page).
external_link: 

image:
  caption: Simulation by Shagun Agarwal
  focal_point: Smart
  preview_only: true
  
authors:
- admin

---

{{< figure src="../../img/nivar_aqua_t1.gif" title="**Figure:** Storm-surge and wind-shear during the landfall of a cylone on the south-eastern coast of India." >}}
