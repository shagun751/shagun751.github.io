---
title: CBS method for viscous flow
summary: Development of 2D finite element model for viscous flow around strucutres using the CBS scheme.
tags:
- Numerical
- FEM
- Other
date: "2022-05-21T00:00:00Z"

# Optional external URL for project (replaces project detail page).
external_link: https://sites.google.com/view/shagunagarwal/other-research/cbs-free-surface?authuser=0

image:
  caption: Snapshot by Shagun Agarwal
  focal_point: Smart
---
