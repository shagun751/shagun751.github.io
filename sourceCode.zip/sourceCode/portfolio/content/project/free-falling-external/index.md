---
title: Water-impact using Star-CCM+ and ANSYS Fluent
summary: Simulation of water-impact on freely-falling wedge simulated using overset and adaptive mesh techinques.
tags:
- Numerical
- Other
date: "2022-05-21T00:00:00Z"

# Optional external URL for project (replaces project detail page).
external_link: https://sites.google.com/view/shagunagarwal/other-research/freely-falling-wedge?authuser=0

image:
  caption: Snapshot by Shagun Agarwal
  focal_point: Smart
---
