---
title: Underwater rover
summary: A rover for inspection cracks in underwater surfaces using ultrasonic sensors.
tags:
- Robotics
- Prototype
- Raspberry Pi
- Arduino
date: "2021-03-06T00:00:00Z"

# Optional external URL for project (replaces project detail page).
external_link: 

image:
  caption: Photo by Shagun Agarwal
  focal_point: Smart
  preview_only: true

---

{{< figure src="./featured.jpg" title="**Figure:** Snapshot showing the essential design features of the under rover prototype." >}}

{{< youtube id="fRpp4Y5Z-fw" autoplay="false" title="Video showing the defect detection" >}} 

---

