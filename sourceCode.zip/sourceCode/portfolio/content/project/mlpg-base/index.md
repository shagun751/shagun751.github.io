---
title: Navier-Stokes-MLPG for 3D free-surface flows
summary: A Meshless Local Petrov Galerkin method (MLPG) for solving 3D Navier-Stokes equations for fluid flow with free-surface.
tags:
- MLPG
- Numerical
- Meshless
date: "2021-03-04T00:00:00Z"

# Optional external URL for project (replaces project detail page).
external_link: 

image:
  caption: Simulation by Shagun Agarwal
  focal_point: Smart
  preview_only: true
  
authors:
- admin

---

{{< figure src="../../img/project_mlpg_base_3D.gif" title="**Figure:** Focusing wave impact on vertical cylinder simulated using 3D particle-based model for free-surface flows." >}}
