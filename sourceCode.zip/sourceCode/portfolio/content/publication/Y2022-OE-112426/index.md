---
title: "Three-dimensional coupling between Boussinesq (FEM) and Navier-Stokes (particle based) models for wave structure interaction"
authors:
- Shagun Agarwal
- V. Sriram
- K. Murali
date: "2022-11-01T00:00:00Z"
doi: "10.1016/j.oceaneng.2022.112426"

# Schedule page publish date (NOT publication's date).
publishDate: "2022-09-01T00:00:00Z"

# Publication type.
# Legend: 0 = Uncategorized; 1 = Conference paper; 2 = Journal article;
# 3 = Preprint / Working Paper; 4 = Report; 5 = Book; 6 = Book section;
# 7 = Thesis; 8 = Patent
publication_types: ["2"]

# Publication name and optional abbreviated publication name.
publication: "Ocean Engineering, 263"
publication_short: ""

abstract: The paper presents coupling between a mesh-based finite-element model for Boussinesq equations (FEBOUSS Agarwal et al., 2022) with a meshless local Petrov–Galerkin model for the Navier–Stokes equations (MLPG_R Agarwal et al., 2021) in 3D. Boussinesq equation models are widely used for simulating wave-propagation over large domains with uneven topography using a 2D surface mesh. Mesh-less models inherently capture large free-surface deformations and have shown promise in simulating wave-structure interaction, run-up and breaking phenomenon. The hybrid approach in this paper assumes a 3D MLPG_R sub-domain surrounded by the 2D mesh of FEBOUSS. The coupling interface in MLPG_R consists of relaxation zones that can be placed along multiple boundaries of the sub-domain for exchanging particle velocity from FEBOUSS. This hybrid model is therefore capable of simulating directional waves, that has not been reported previously. The paper first presents the procedure for calculating the depth-resolved velocities in 3D from the Boussinesq model. The resultant velocities are compared against theory, experiments and other models. The following sections present the coupling algorithm along a single and multiple coupling interfaces in MLPG_R. Validation results for this hybrid model are provided using surface elevation and velocity measurements for regular waves, including directional cases. In general, the results from the hybrid model are reported to have marginal over-prediction of peaks compared to purely MLPG_R simulation. Finally, the interaction of a vertical cylinder with direction regular wave is simulated using the 3D hybrid model.

# Summary. An optional shortened abstract.
summary: 3D coupling between mesh-based potential and particle-based viscous flow models.

tags:
- Publications
- Journal
- Bsnq

featured: true

# links:
# - name: ""
#   url: ""
url_pdf: "files/Y2022-OE-112426.pdf"
# url_code: ''
# url_dataset: ''
# url_poster: ''
# url_project: ''
# url_slides: ''
# url_source: ''
# url_video: ''

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
image:
  caption: 'Image credit: Shagun Agarwal'
  focal_point: "center"
  preview_only: true

# Associated Projects (optional).
#   Associate this publication with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `internal-project` references `content/project/internal-project/index.md`.
#   Otherwise, set `projects: []`.
projects: [bsnq-base, mlpg-base]

# Slides (optional).
#   Associate this publication with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides: "example"` references `content/slides/example/index.md`.
#   Otherwise, set `slides: ""`.
# slides: example
---


{{% alert note %}}
Click the *Cite* button above to demo the feature to enable visitors to import publication metadata into their reference management software.
{{% /alert %}}

{{% alert note %}}
Click the *Slides* button above to demo academia's Markdown slides feature.
{{% /alert %}}


{{< figure src="./featured.png" title="**Figure:** " >}}

