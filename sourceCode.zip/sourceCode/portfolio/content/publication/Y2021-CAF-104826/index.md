---
title: "Improvements in MLPG formulation for 3D wave interaction with fixed structures"
authors:
- Shagun Agarwal
- V. Sriram
- Shiqiang Yan
- K. Murali
date: "2021-03-30T00:00:00Z"
doi: "10.1016/j.compfluid.2020.104826"

# Schedule page publish date (NOT publication's date).
publishDate: "2021-03-01T00:00:00Z"

# Publication type.
# Legend: 0 = Uncategorized; 1 = Conference paper; 2 = Journal article;
# 3 = Preprint / Working Paper; 4 = Report; 5 = Book; 6 = Book section;
# 7 = Thesis; 8 = Patent
publication_types: ["2"]

# Publication name and optional abbreviated publication name.
publication: "Computers and Fluids, 218"
publication_short: ""

abstract: This paper presents new developments in meshless local Petrov-Galerkin with Rankine source (MLPG_R) particle based method for studying interaction of waves with fixed structures in a numerical wave-tank. A new 3D formulation of the Lagrangian flow problem for incompressible fluid with optimised solution strategy is presented. The pressure Poisson equation is solved in local weak-form with integration done semi-analytically using a new symmetric expression. The wave-generation is done using one-way coupling with a 2D fully-nonlinear potential theory based finite-element model. Further a simple identification method for free-surface particles is proposed, which is shown to work well in vicinity of the structure. The solid-wall boundary condition is treated using ghost and mirror particles for accurate calculation of gradients. The waterline on domain boundary faces is treated using a tangentially moving side-wall approach which makes this particle based scheme capable of capturing small amplitude waves and focusing waves. The paper briefly presents experimental setup used for studying the interaction of a fixed emergent cylinder with uni-directional regular and focusing waves in 3D. The numerical model is validated against results from this experiment. An analysis is conducted on parameters related to local integration domain, wave-making coupling algorithm, particle distribution and time-step. This work highlights the use of hybrid approach for efficient and accurate simulation of waves-structure interaction.

# Summary. An optional shortened abstract.
summary: Developments and analysis on the MLPG method in 3D for interaction of steep non-breaking focusing waves with fixed cylinder.

tags:
- Publications
- Journal
- MLPG

featured: true

# links:
# - name: ""
#   url: ""
url_pdf: "files/Y2021-CAF-104826-Accepted.pdf"
# url_code: ''
# url_dataset: ''
# url_poster: ''
# url_project: ''
# url_slides: ''
# url_source: ''
# url_video: ''

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
image:
  caption: 'Image credit: Shagun Agarwal'
  focal_point: "center"
  preview_only: true

# Associated Projects (optional).
#   Associate this publication with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `internal-project` references `content/project/internal-project/index.md`.
#   Otherwise, set `projects: []`.
projects: [mlpg-base]

# Slides (optional).
#   Associate this publication with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides: "example"` references `content/slides/example/index.md`.
#   Otherwise, set `slides: ""`.
# slides: example
---


{{% alert note %}}
Click the *Cite* button above to demo the feature to enable visitors to import publication metadata into their reference management software.
{{% /alert %}}

{{% alert note %}}
Click the *Slides* button above to demo academia's Markdown slides feature.
{{% /alert %}}


The paper presented a detailed new 3D formulation of the solution procedure for Navier-Stokes equation for incompressible Lagrangian flow problem using MLPG. The existing MLPG_R scheme with it Petrov–Galerkin formulation using Rankine source had the significant advantage of removing gradient operations from the unknown quantity. This paper has additionally provided the derivation of a semi-analytical integration technique with a symmetric expression (MLPG_RS) and has quantified the associated error. A detailed analysis of the influence of the integration domain radius on the stability and accuracy of the solution was conducted to understand the integration method error. Based on this, we have prescribed the radius of the support domain and the integration domain.

{{< figure src="./featured.png" title="**Figure:** 3D Surface plot for velocity magnitude in the vicinity of the cylinder under the action of the steepest trough in focusing wave" >}}

A detailed algorithm was presented for coupling of 2D FNPT-FEM with the 3D MLPG_RS method. This hybrid approach was used as the wave-making condition, which limited the need for 3D domain to the vicinity of the cylinder. It allowed us to significantly reduce the 3D computational domain and number of time-steps, and has improved the overall computational efficiency of the model. A detailed analysis was done to identify the appropriate size of overlapping zone between the 2D and the 3D domain for solitary, regular and focusing waves. The paper presents minimum overlapping zone length criterion for successful coupling. We were able to use the strength of potential flow model in accurate wave-generation and propagation over long distances, due to which the wave reaching the cylinder was highly accurate and resulted in excellent agreement of numerical pressure probe signals with the experiments.

We have demonstrated the issue of mis-identification of free-surface particles in the vicinity of the cylinder with the existing scheme and have provided a simple alternative technique instead. A moving wall algorithm was presented to capture the waterline on side-wall faces. It enabled the model to capture small amplitude waves and thus made it possible to accurately replicate a focusing wave. We briefed upon the other improvements in application of rigid wall boundary condition, particle collision and redistribution. The collective result of these modifications was demonstrated through pressure probe signal comparison, highlighting the improvements in the accuracy and the stability.

MLPG_RS has the strength of simulating complex flows using relatively lesser number of nodes in comparison to other particle based schemes. This was demonstrated through the mesh and time-step convergence study in this paper. We highlighted the capabilities through excellent comparison of pressure for probes located outside the initial water level. We have also conducted a mesh and time-step convergence study and have demonstrated the suitable range of parameters for interaction of waves with fixed structures. This work has set the basis for further developments in MLPG towards 3D simulation of moving and floating bodies. The hybrid modelling approach will be extended to further reduce the computational domain by shifting the absorbing layer to a potential flow model. Such developments can help bring particle based schemes in the mainframe.

The present manuscript has presented and validated a baseline laminar 3D MLPG model. The complex cases of interaction of cylinder with banded steep focusing wave helped us identify issues with the model which may be hidden under the noise of breaking waves. Therefore, with the confidence in the improvements presented in this manuscripts we will present a detailed study on breaking waves in 3D using MLPG in our future work.

Supplementary notes can be added here, including [code and math](https://sourcethemes.com/academic/docs/writing-markdown-latex/).
