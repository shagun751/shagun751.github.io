---
title: "Modelling Wave Interaction with Porous Structures Using Boussinesq Equations"
authors:
- Shagun Agarwal
- V. Sriram
- K. Murali
date: "2019-01-17T00:00:00Z"
doi: "10.1007/978-981-13-3119-0_35"

# Schedule page publish date (NOT publication's date).
publishDate: "2021-03-06T00:00:00Z"

# Publication type.
# Legend: 0 = Uncategorized; 1 = Conference paper; 2 = Journal article;
# 3 = Preprint / Working Paper; 4 = Report; 5 = Book; 6 = Book section;
# 7 = Thesis; 8 = Patent
publication_types: ["1"]

# Publication name and optional abbreviated publication name.
publication: In *Proceedings of the Fourth International Conference in Ocean Engineering (ICOE2018)*
publication_short: In *ICOE2018*

abstract: The paper presents a numerical model of the two-dimensional enhanced Boussinesq equations to simulate wave transformations in the near-shore region. The finite element-based discretisation over unstructured mesh with triangular elements uses mixed linear and quadratic shape functions. The domain integrals are calculated analytically. The model is extended to study flow through porous structures using Darcy velocity, with the energy dissipation within the porous medium modelled through additional laminar and turbulent resistance terms. A single set of empirical constants gives accurate prediction for various stone sizes and porosity. This paper reports the model development and its validation using existing experimental studies. Application of the model is demonstrated by studying the interaction between ship-generated waves in a narrow channel and the porous walls of the channel.

# Summary. An optional shortened abstract.
summary: Presenting a FEM model for Madsen form of Boussinesq equations for modelling transformation of ocean waves over variable bathymetry. Additional developments include flow through porous breakwater and ship-generated waves.

tags:
- Publications
- Conference
- Boussinesq

featured: false

links:
#- name: Custom Link
#  url: http://example.org
url_pdf: "files/Y2018-ICOE-Conf.pdf"
# url_code: '#'
# url_dataset: '#'
# url_poster: '#'
# url_project: ''
# url_slides: ''
# url_source: '#'
# url_video: '#'

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
image:
  caption: 'Image credit: Shagun Agarwal'
  focal_point: "center"
  preview_only: true

# Associated Projects (optional).
#   Associate this publication with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `internal-project` references `content/project/internal-project/index.md`.
#   Otherwise, set `projects: []`.
projects: [bsnq-base]
# - internal-project

# Slides (optional).
#   Associate this publication with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides: "example"` references `content/slides/example/index.md`.
#   Otherwise, set `slides: ""`.
# slides: example
---

{{% alert note %}}
Click the *Cite* button above to demo the feature to enable visitors to import publication metadata into their reference management software.
{{% /alert %}}

{{% alert note %}}
Click the *Slides* button above to demo academia's Markdown slides feature.
{{% /alert %}}

{{< figure src="./featured.png" title="**Figure:** Transformation of regular waves over the complex Berkhoff shoal bathymetry." >}}

Supplementary notes can be added here, including [code and math](https://sourcethemes.com/academic/docs/writing-markdown-latex/).

