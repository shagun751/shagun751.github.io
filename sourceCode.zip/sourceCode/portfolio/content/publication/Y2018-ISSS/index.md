---
title: "Demonstration of control and inspection by circumferentially guided ultrasonic waves using novel Remotely Operated Underwater Vehicle"
authors:
- admin
- Tanij Jhunjhunwala
- NT Saikiran
- Prabhu Rajagopal
date: "2018-10-23T00:00:00Z"
doi: "10.1007/s41683-018-0031-5"

# Schedule page publish date (NOT publication's date).
publishDate: "2021-03-07T00:00:00Z"

# Publication type.
# Legend: 0 = Uncategorized; 1 = Conference paper; 2 = Journal article;
# 3 = Preprint / Working Paper; 4 = Report; 5 = Book; 6 = Book section;
# 7 = Thesis; 8 = Patent
publication_types: ["2"]

# Publication name and optional abbreviated publication name.
publication: "ISSS Journal of Micro and Smart Systems, volume 7"
publication_short: ""

abstract: This article presents a cost efficient semi-autonomous remotely operated underwater vehicle for inspecting water-submerged pipeline networks using circumferential guided ultrasonic waves. Robot navigation is implemented using inertial measurement unit and pressure sensor, with motion control achieved through proportional–integral–differential controller specially tuned to take angled turns. The robot is equipped with pneumatic grippers for clamping on-to a pipe and uses thrusters to move along its length. The paper describes the electronics and control design of this mechanism and presents results from practical experimental trials and ultrasonic measurements.

# Summary. An optional shortened abstract.
summary: A controlled underwater ROV for inspecting submerged pipes using circumferentially guided ultrasonic waves.

tags:
- Publications
- Journal
- Robotics
- Raspberry Pi
- Arduino

featured: true

# links:
# - name: ""
#   url: ""
url_pdf: "./Y2018-ISSS.pdf"
# url_code: ''
# url_dataset: ''
# url_poster: ''
# url_project: ''
# url_slides: ''
# url_source: ''
# url_video: ''

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
image:
  caption: 'Image credit: Shagun Agarwal'
  focal_point: "center"
  preview_only: true

# Associated Projects (optional).
#   Associate this publication with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `internal-project` references `content/project/internal-project/index.md`.
#   Otherwise, set `projects: []`.
projects: [ROV]

# Slides (optional).
#   Associate this publication with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides: "example"` references `content/slides/example/index.md`.
#   Otherwise, set `slides: ""`.
# slides: example
---


{{% alert note %}}
Click the *Cite* button above to demo the feature to enable visitors to import publication metadata into their reference management software.
{{% /alert %}}

{{% alert note %}}
Click the *Slides* button above to demo academia's Markdown slides feature.
{{% /alert %}}

{{< youtube id="HxKO0T91lI4" autoplay="false" title="Video demonstrating the control algorithm of the underwater ROV." >}} 

The video above shows the prototype underwater ROV designed for inspection of submerged pipes. Control and sensing implemented using Raspberry Pi microprocessor and Arduino microcontroller. The system is capable of live camera feed from 2 1080p cameras, IMU for navigation, pressure sensor for depth estimation and high sampling ultrasonic sensor for with generation and sensing of circumferentially guided ultrasonic pulses.

The ROV was hence able to meet the primary objective. The novel design of the pneumatic gripper on the ROV hull is able to grip underwater pipes with reasonable strength. The ROV demonstrated that the combination of processing power of Raspberry-Pi and Arduino Mega, along with feedback sensors like IMU and pressure sensor can be used for controlling multiple degrees of freedom of motion simultaneously and hence provide a reliable navigation to a submerged pipeline network. It can successfully hover over pipe and grip it using the pneumatic grippers. The specially tuned motion control ensures that ROV can move along a pipe’s length and take angled turns when necessary over the pipeline network. The affordable hardware has also been made to handle the large amount of data real-time from two mounted cameras for a live feed and ultrasonic probe. It has also successfully demonstrated the use of circumferential guided ultrasonic waves for detecting defects on pipeline surface.

{{< figure src="./featured.png" title="**Figure:** Side view of the ROV prototype with major parts specified." width=50% >}}

This system hence overcomes the shortcoming of pigging as it can comfortably make sharp angled turns, provide live feedback of data and can run for long periods of time as it is externally powered. Also, it does not expose the pipeline to surrounding atmosphere and thus avoids any chance of contamination and addresses the safety concerns regarding insertion and removal of a pig device. In case more processing power is required, an arrangement using multiple Raspberry-Pi or using ones with better specifications, such as Raspberry-Pi 2 with 1 GB of RAM and a 900 MHz quad core processor; would be more effective as compared to available alternatives. The same system can be modified for inspecting large tank floors too.

This work has presented the proof of concept of using ultrasonics for defect detection using ROVs. With this basis, the future work will investigate complex problems such as identification of the defect, use of an array of ultrasonic sensors for simultaneous analysis, etc. Additionally, this work shows the ability of the communication and electronics architecture built using affordable and readily available microprocessor and sensors to handle the large amount of data associated with simultaneous ultrasonic sensing and ROV control. This approach can be scaled for increased complexity in control and sensing.

Supplementary notes can be added here, including [code and math](https://sourcethemes.com/academic/docs/writing-markdown-latex/).
