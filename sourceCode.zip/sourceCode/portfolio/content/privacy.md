---
title: Privacy Policy
date: "2021-03-06T00:00:00+01:00"
draft: true
share: false

# Optional header image (relative to `static/img/` folder).
header:
  caption: ""
  image: ""
---

Content owned by Shagun Agarwal. Please contact by mail for any clarifications.